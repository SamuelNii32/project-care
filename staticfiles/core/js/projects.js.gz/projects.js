$(document).ready(function(){
    const typewriter = document.querySelector("#typewriter");
    tinyTypewriter(typewriter, {
        items: ['topics.', "materials."]
    });
});
